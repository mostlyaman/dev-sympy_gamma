import sympy
from sympy import *
from sympy.integrals.manualintegrate import manualintegrate
π = pi
